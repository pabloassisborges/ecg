# importing the required module 
import matplotlib.pyplot as plt 
import pandas as pd
from io import StringIO

data = pd.read_csv('ekg.csv', sep=';').iloc[:, 1:]

print(data)
print("\n")
  
# plotting the points  
plt.plot(data) 
  
# naming the x axis 
plt.xlabel('x - axis') 
# naming the y axis 
plt.ylabel('y - axis') 
  
# giving a title to my graph 
plt.title('ECG') 
  
# function to show the plot 
plt.show() 
##data = importdata('ekg1.txt')
##x = data(:, 1);
##y = data(:, 2);
##plot(filter(x, y), 'b-', 'LineWidth', 2);
##title('ECG Signal', 'FontSize', 20);
##xlabel('Time', 'FontSize', 20);
##ylabel('Voltage', 'FontSize', 20);
##grid on;
##% Enlarge figure to full screen.
##set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.96]);

pkg load signal

Fs = 1E+3;                                          % Sampling Frequency
Fn = Fs/2;                                          % Nyquist Frequency
b=fir1(48, [59.8 60.2]/Fn, 'stop');
freqz(b, 1, 2^16, Fs)
dataIn=load('noisy_ECG.mat');
c=struct2cell(dataIn);
d=cell2mat(c);
dataOut=filter(b,1,d);
e=[0:9999];
plot(e,dataOut)
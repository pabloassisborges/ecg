class ECGModel:
    def __init__(self):
        self.message = "ECG Getted!"
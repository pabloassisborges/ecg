class WelcomeModel:
    def __init__(self):
        self.message = "Hello World!"
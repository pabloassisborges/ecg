import os
from http import HTTPStatus
from flask import Blueprint, request
from flasgger import swag_from
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from api.model.welcome import WelcomeModel
from api.schema.welcome import WelcomeSchema
from api.model.getECG import ECGModel
from api.schema.getECG import ECGSchema
from api.services.database import hello


home_api = Blueprint('api', __name__)


@home_api.route('/', methods=["GET"])
@swag_from({
    'responses': {
        HTTPStatus.OK.value: {
            'description': 'Welcome to the Flask Starter Kit',
            'schema': WelcomeSchema
        }
    }
})
def welcome():
    """
    The home route, that returns a "hello world" if the server is running up ok.
    This is a Hello-world endpoint, only for design a model for the order endpoint structure.
    ---
    """
    result = WelcomeModel()
    return WelcomeSchema().dump(result), 200



@home_api.route('/getEletrocardiogram', methods=["GET"])
@swag_from({
    'responses': {
        HTTPStatus.OK.value: {
            'description': 'Getting the ECG exam from the database and display at the screen.',
            'schema': ECGSchema
        }
    }
})
def getECG():
    """
    The getECG route, which will be used to recive the data from ECG.
    ---
    """
    try:
        print("ECG")
        result = ECGModel()
        return ECGSchema().dump(result), 200
    except Exception as e:
        print(e)
        return ECGSchema().dump(e), 400




@home_api.route('/getUsers', methods=["GET"])
@swag_from({
    'responses': {
        HTTPStatus.OK.value: {
            'description': 'Getting mock users and display at the screen.',
            'schema': ECGSchema
        }
    }
})
def getECG():
    """
    The getECG route, which will be used to recive the data from ECG.
    ---
    """
    try:
        print("ECG")
        result = ECGModel()
        return ECGSchema().dump(result), 200
    except Exception as e:
        print(e)
        return ECGSchema().dump(e), 400


# api-ecg

## Useful Links
- [Gist](https://gist.github.com/martyychang/194cf927b7f2caef720cd9adbd243f21): Gits structure web API using Python
- [StructureAPI](https://docs.python-guide.org/writing/structure/): Tips for structure your API Python project.
- [StarterKit](https://livecodestream.dev/post/2020-05-21-python-flask-api-starter-kit-and-project-layout/): Starter kit for Python API's with Flask
- [Python3-Flask-Rest-API](https://github.com/matthieugouel/python-flask-api-skeleton): Python3 Flask REST API skeleton.

## Dependencies

- [flask](https://palletsprojects.com/p/flask/): Python server of choise
- [flasgger](https://github.com/flasgger/flasgger): Used to generate the swagger documentation
- [flask-marshmallow](https://flask-marshmallow.readthedocs.io/en/latest/): My favourite serializer
- [apispec](https://apispec.readthedocs.io/en/latest/): Required for the integration between marshmallow and flasgger

## Set Up

1. Check out the code
2. Install requirements
    ```
    pipenv install
    ```
3. Start the server with:
    ```
   pipenv run python -m flask run
    ```

4. Visit http://localhost/apidocs for the Swagger Documentation
   
## Tests

The code is covered by tests, to run the tests please execute

```
pipenv run python -m unittest
```